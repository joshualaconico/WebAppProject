<?php
if(isset($_GET['i'])){
	$servername = "localhost";
	$username = "root";
	$password = "";
	$i = $_GET['i'];
	$conn = mysqli_connect($servername, $username, $password);
	if (!$conn){
		die("connection failed: ". mysqli_connect_error());
	} else {
		echo "connected successfully";
	}
	mysqli_select_db($conn, "papasabaako");
	
	$result = mysqli_query($conn,"SELECT * FROM gagalingankosafinals WHERE user_id = $i");
	
	$row = mysqli_fetch_array($result);
	echo "<form method = 'post'>";
	echo "<input type = 'text' name = 'username' value = '".$row['username']."'>";
	echo "<input type = 'email' name = 'email' value = '".$row['email']."'>";
	echo "<input type = 'lname' name = 'lname' value = '".$row['lname']."'>";
	echo "<input type = 'fname' name = 'fname' value = '".$row['fname']."'>";
	echo "<input type = 'submit' name = 'update' value = 'UPDATE'>";
	echo "</form>";
}
if(isset($_POST['update'])){
	$username = $_POST['username'];
	$email = $_POST['email'];
	$lname = $_POST['lname'];
	$fname = $_POST['fname'];
	
	$sql = "UPDATE gagalingankosafinals SET username = '$username',email ='$email',fname='$fname',lname='$lname' WHERE user_id = $i";
	$result = mysqli_query($conn,$sql);
	if($result)
		echo "updated";
	else
		echo "failed";
}
echo "<br>";

?>
<a href="homepage.php">go back </a>