<?php

//	if(isset($_POST['register'])){
		$servername = "localhost";
		$username = "root";
		$password = "";

		// Create connection
		$conn = mysqli_connect($servername, $username, $password);
		mysqli_select_db($conn, "papasabaako");
		// Check connection
		if (!$conn) {
	    	die("Connection failed: " . mysqli_connect_error());
		} else{
		$myusername = mysqli_real_escape_string($conn,$_POST['uname']);
		$mypassword = mysqli_real_escape_string($conn,$_POST['pass']);
		$pass = md5($mypassword);
		$sql = "SELECT user_id FROM gagalingankosafinals WHERE username = '$myusername' and password = '$pass'";
		
      $result = mysqli_query($conn,$sql);
      $row = mysqli_fetch_array($result);
      $active = $row['status'];
      
      $count = mysqli_num_rows($result);
	  echo $count;
	  if($count == 1){
		session_start();
		$_SESSION['isLogin']=true;
		$_SESSION['username']=$myusername;
		header("location:homepage.php");
	  }
	  else{
			echo "<h3 style = 'color:red;'>
			incorrect login credentials!
			</h3>
			<br>
			<a href = 'yey.php'>Click here to login</a>";
		}
	}	
	
?>