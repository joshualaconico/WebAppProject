



<form action ="session2.php" method = "post">
<div>
	<label for ="">Username</label>
	<input type = "text" name="uname">
</div>
<div>
	<label for="">Password</label>
	<input type ="password" name="pass">
</div>
<div>
	<input type ="submit" name = "login">
</div>
</form>
<a href="register.php">click here to register </a>