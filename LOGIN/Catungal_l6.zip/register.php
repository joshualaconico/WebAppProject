<?php
	if(isset($_POST['register'])){
	$servername = "localhost";
	$username = "root";
	$password = "";
	
	
	//create connection
	$conn = mysqli_connect($servername, $username, $password);
	if (!$conn){
		die("connection failed: ". mysqli_connect_error());
	} else {
		echo "connected successfully";
		echo "<br>";
	}

	
	mysqli_select_db($conn, "papasabaako");
		
	$username = $_POST['username'];
	$email = $_POST['email'];
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$mname = $_POST['mname'];
	$gender =$_POST['gender'];
	$pass = $_POST['password'];
	$rpass = $_POST['rpassword'];
	
if(empty($username) || empty($fname) || empty($lname) ||
				empty($mname) || empty($gender) || empty($pass) || empty($rpass)){
				echo "<span>empty fields exist</span>";
			}
			else if($pass != $rpass){
				echo "<span>password do not match</span>";
			} else{
				$sql = "SELECT * FROM gagalingankosafinals WHERE username = '$username' OR email = '$email'";
				$result = mysqli_query($conn, $sql);

				if(mysqli_num_rows($result) > 0){
					echo "<span>username or email already exists</span>";
				} else {
					$pass = md5($pass);
					$sql = "INSERT INTO gagalingankosafinals
								(username, email, fname, lname, mname, gender, password, status)
								VALUES('$username', '$email', '$fname',
									'$lname', '$mname', '$gender', '$pass',
									0)";

					$result = mysqli_query($conn, $sql);
					if($result)
						echo "Registration successfull!";
					else
						echo "<span>error in registration</span>";
				}
			}


		}
?>


<form method="post">
	<input type = "text" name = "username" placeholder = "Username"><br>
	<input type = "email" name = "email" placeholder = "Email"><br>
	<input type = "text" name = "fname" placeholder = "First Name"><br>
	<input type = "text" name = "lname" placeholder = "Last Name"><br>
	<input type = "text" name = "mname" placeholder = "Middle Name"><br>
	Gender:
	<input type ="radio" name="gender" value = "M">M
	<input type = "radio" name="gender" value ="F">F<br>
	
	<input type = "password" name="password" placeholder="Password"> <br>
	<input type = "password" name="rpassword" placeholder="Re-enter Password"> <br>
	<input type ="submit" name="register" value="REGISTER">
</form>

<a href="yey.php">click here to login</a>
	
	
	
