function brr()
{
	alert("Succesfuly Submitted")
}
function beb()
{
	alert("You remove all the data")
}
// var image_tracker = 'orange';
var b1 = document.getElementById("bilang1").value;
var p1 = document.getElementById("pera1").value;
function bq()
{
	// var image = 
	document.getElementById("image").src="bqclick.jpg";
	// if(image_tracker=='orange'){
 // image.src='bqclick.jpg';
 // image_tracker='blue';
 // }
 // else{
 // image.src='bq.png';
 // image_tracker='orange';
 // }
	if(isNaN(b1) || isNaN(p1))
	{
		alert("Wala kang binili")
	}
}
function tok()
{
	document.getElementById("image1").src="tokneclq.jpg";
		alert("UBOS NA")
}
function turon()
{
	document.getElementById("image2").src="turoncliq.jpg";
		alert("UBOS NA")
}
function cala()
{
		alert("empty fields exist")
}
	
